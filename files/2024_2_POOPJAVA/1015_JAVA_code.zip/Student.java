public class Student extends Person{ 
    private int id;
    public Student() {super();}//生成无参构造
    public Student(String name, int age,int id) {
        super(name, age); 
        setId(id);
    }
    public Student(int id) {
        super(); this.id = id;
    }//生产有参构造
    public int getId() {return id;}//生成get和set方法 
    public void setId(int id) {
        if(id>0){
            this.id=id; 
        }else{
            System.out.println("学号不合理!!");
        }
    } 
    public void show(){ //super.show(); 
        System.out.println("学号: "+getId());
    }
    // @Override
    public static void test(){
        System.out.println("Student类的静态方法");
    } 
}
