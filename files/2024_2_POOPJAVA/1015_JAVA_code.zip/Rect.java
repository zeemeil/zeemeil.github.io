public class Rect extends Shape{
    private int len;
    private int vid;
    public Rect() {super();}
    public Rect(int len, int vid, int x, int y) {
        super(x,y); 
        setLen(len);setVid(vid);
    }
    public int getLen() {return len;}
    public void setLen(int len) {this.len = len;}
    public int getVid() {return vid;}
    public void setVid(int vid) {this.vid = vid;}
    @Override
    public void show() {
        super.show();
        System.out.println("len="+getLen()+",vid="+getVid());
    }
}
