public class TestSubAbstract extends TestAbstract {
    @Override
    public void show() {System.out.println("抽象类果然不同");}
    public static void main(String[] args){
    TestSubAbstract  ts= new  TestSubAbstract();
    ts.show();//子类的引用只能调用自己的show方法
    System.out.println("--------------");
    TestAbstract ta=new TestSubAbstract();//父类的引用指向子类的对象，形成多态
    ta.show();//在编译阶段调用父类的show()，在运行阶段调用的子类重写父类以后的方法}
    }
}
