public abstract class TestAbstract {
    private int num;
    public TestAbstract(int num) {this.num = num;}
    public TestAbstract() {}
    // public abstract void show();
    public void show(){
        System.out.println("show方法");
    }

    // public static void main(String[] args){
    //     TestAbstract t=new TestAbstract();
    //     t.show();
    // }
        

}
