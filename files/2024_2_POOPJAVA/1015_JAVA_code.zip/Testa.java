public class Testa {
    public static void main(String[] args){
        Rect rect=new Rect(1,2,3,4);
        rect.show();
        Circle cir=new Circle(5,6,7);
        cir.show();
    }
}

