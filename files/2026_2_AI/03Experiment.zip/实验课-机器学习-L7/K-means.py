import cv2
import numpy as np
import os
import matplotlib.pyplot as plt

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score

from mpl_toolkits.mplot3d import Axes3D


# =========================================
# 1. 特征提取函数
# =========================================
def extract_color_features(image_path):
    img = cv2.imread(image_path)

    if img is None:
        print(f"无法加载图像: {image_path}")
        return None

    # 平均 BGR
    B_mean, G_mean, R_mean = np.mean(img, axis=(0, 1))
    return np.array([B_mean, G_mean, R_mean])


# =========================================
# 2. 数据加载
# =========================================
base_dir = r'C:\Users\502\Desktop\experiment_data'  # ← 修改路径

data_paths = {
    "nut": os.path.join(base_dir, 'nuts'),
    "washer": os.path.join(base_dir, 'washers')
}

features = []
labels = []
label_map = {"nut": 0, "washer": 1}

print("=== 加载数据 ===")

for item_name, folder_path in data_paths.items():
    label = label_map[item_name]
    print(f"处理类别: {item_name}")

    for filename in os.listdir(folder_path):
        if filename.endswith(('.jpg', '.png', '.jpeg')):
            path = os.path.join(folder_path, filename)
            feat = extract_color_features(path)

            if feat is not None:
                features.append(feat)
                labels.append(label)

X = np.array(features)
Y = np.array(labels)

print(f"样本数量: {len(X)}")
print(f"特征维度: {X.shape}")


# =========================================
# 3. K-means 聚类
# =========================================
print("\n=== K-means 聚类 ===")

kmeans = KMeans(n_clusters=2, random_state=42)
cluster_labels = kmeans.fit_predict(X)

print("前10个聚类标签:", cluster_labels[:10])


# =========================================
# 4. Step 1：二维投影（B-G）
# =========================================
plt.figure()
plt.scatter(X[:, 0], X[:, 1], c=cluster_labels)
plt.xlabel("B_mean")
plt.ylabel("G_mean")
plt.title("Step 1: 2D Projection (B-G)")
plt.show()


# =========================================
# 5. Step 2：三维真实空间
# =========================================
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

ax.scatter(X[:, 0], X[:, 1], X[:, 2], c=cluster_labels)

ax.set_xlabel('B_mean')
ax.set_ylabel('G_mean')
ax.set_zlabel('R_mean')

plt.title("Step 2: 3D Feature Space")
plt.show()


# =========================================
# 6. Step 3：PCA降维
# =========================================
print("\n=== PCA 降维 ===")

pca = PCA(n_components=2)
X_pca = pca.fit_transform(X)

print("降维后形状:", X_pca.shape)


# PCA + 聚类
plt.figure()
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=cluster_labels)
plt.title("Step 3: PCA + K-means")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.show()


# =========================================
# 7. PCA + 真实标签（用于对比）
# =========================================
plt.figure()
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=Y)
plt.title("PCA (True Labels)")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.show()


# =========================================
# 8. 聚类评估（教学用）
# =========================================
print("\n=== 聚类评估 ===")

ari = adjusted_rand_score(Y, cluster_labels)
print(f"ARI指标: {ari:.3f}")


# =========================================
# 9. 找“错误样本”
# =========================================
print("\n=== 被聚类“分错”的样本 ===")

for i in range(len(Y)):
    if cluster_labels[i] != Y[i]:
        print(f"样本 {i} 被分错（真实={Y[i]}，聚类={cluster_labels[i]}）")


# =========================================
# 10. K值变化实验（可选）
# =========================================
print("\n=== K值影响 ===")

for k in [2, 3, 4]:
    km = KMeans(n_clusters=k, random_state=42)
    labels_k = km.fit_predict(X)

    score = adjusted_rand_score(Y, labels_k)
    print(f"K={k} -> ARI={score:.3f}")
