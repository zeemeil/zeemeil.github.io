# -*- coding: utf-8 -*-
"""
古诗词情绪分类器

"""

import jieba
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import re

# ========== 请在这里修改文件路径 ==========
train_file = r'C:\Users\502\Desktop\train.txt'      # 训练数据文件
test_file = r"C:\Users\502\Desktop\test.txt"        # 测试数据文件
test_has_label = False          # 是否强制指定测试集有标签：True=有，False=自动检测（推荐）
# ==========================================

def clean_path(path):
    """
    移除路径字符串中可能导致OSError的不可见控制字符和方向格式化字符。
    """
    return re.sub(r'[\x00-\x1f\x7f\u200e\u200f\u202a-\u202e]', '', path)

def split_line(line, has_label=True):
    """
    智能分割每行数据，支持 Tab 和空格分隔符。
    返回 (text, label) 元组。
    若 has_label=False，则返回 (整行文本, '')。
    """
    line = line.strip()
    if not line:
        return None, None
    
    if not has_label:
        return line, ''
    
    # 优先尝试 Tab 分隔
    if '\t' in line:
        parts = line.split('\t', 1)
        text = parts[0].strip()
        label = parts[1].strip() if len(parts) > 1 else ''
        return text, label
    
    # 尝试空格分隔（支持多个空格）
    parts = re.split(r'\s+', line, maxsplit=1)
    if len(parts) == 2:
        text = parts[0].strip()
        label = parts[1].strip()
        # 启发式：若第二部分过长或包含标点，则视为文本的一部分（即无标签）
        if len(label) > 20 or any(ch in label for ch in ['，', '。', '？', '！', '；', '：']):
            return line, ''
        return text, label
    else:
        # 没有分隔符，整行作为文本
        return line, ''

# 清洗路径
train_file = clean_path(train_file)
test_file = clean_path(test_file)

# ------------------ 读取训练数据 ------------------
print("正在读取训练数据...")
texts = []
labels = []
error_lines = []
with open(train_file, 'r', encoding='utf-8') as f:
    for line_num, line in enumerate(f, 1):
        text, label = split_line(line, has_label=True)
        if text is None:
            continue
        if text and label:
            texts.append(text)
            labels.append(label)
        elif text and not label:
            print(f"警告：训练数据第 {line_num} 行没有检测到标签，将使用空标签")
            texts.append(text)
            labels.append('unknown')
            error_lines.append(line_num)
        else:
            error_lines.append(line_num)

print(f"读取 {len(texts)} 条训练数据。")
if error_lines:
    print(f"注意：有 {len(error_lines)} 行数据格式异常（行号：{error_lines[:5]}...）")

if len(texts) == 0:
    print("错误：没有读取到任何有效的训练数据！请检查文件格式。")
    print("支持的分隔符：Tab 键或空格键")
    print("示例格式：床前明月光，疑是地上霜。\t思乡")
    exit(1)

# ------------------ 分词 ------------------
print("正在进行中文分词...")
def cut(text):
    return ' '.join(jieba.cut(text))

texts_cut = [cut(t) for t in texts]

# ------------------ 特征提取 ------------------
vectorizer = CountVectorizer(token_pattern=r"(?u)\b\w+\b")
X_train = vectorizer.fit_transform(texts_cut)
print(f"特征维度：{X_train.shape}")

if X_train.shape[1] == 0:
    print("错误：特征提取后词汇表为空！请检查训练数据内容。")
    exit(1)

# ------------------ 训练模型 ------------------
model = MultinomialNB()
model.fit(X_train, labels)
print("模型训练完成。\n")

# ------------------ 读取测试数据（自动检测是否包含标签） ------------------
print("正在读取测试数据...")
test_texts = []
test_labels = []

# 先试探第一行，判断测试文件是否包含标签（除非用户强制指定）
def detect_has_label(file_path):
    """探测测试文件是否包含标签（返回布尔值）"""
    with open(file_path, 'r', encoding='utf-8') as f:
        first_line = f.readline().strip()
        if not first_line:
            return False
        # 如果有 Tab 分隔，判定为有标签
        if '\t' in first_line:
            parts = first_line.split('\t', 1)
            if len(parts) == 2 and parts[1].strip():
                return True
        # 尝试空格分隔，并启发式判断第二部分是否为标签
        parts = re.split(r'\s+', first_line, maxsplit=1)
        if len(parts) == 2:
            second = parts[1].strip()
            # 标签通常较短且不含标点
            if len(second) <= 20 and not any(ch in second for ch in ['，', '。', '？', '！']):
                return True
    return False

# 确定测试集是否有标签：用户指定优先，否则自动检测
if test_has_label is True:
    has_label = True
    print("根据用户设置：测试集包含标签。")
elif test_has_label is False:
    # 自动检测
    has_label = detect_has_label(test_file)
    if has_label:
        print("自动检测：测试集包含标签，将进行评估。")
    else:
        print("自动检测：测试集不包含标签（或无法识别），仅输出预测结果。")
else:
    # 默认自动检测
    has_label = detect_has_label(test_file)
    if has_label:
        print("自动检测：测试集包含标签，将进行评估。")
    else:
        print("自动检测：测试集不包含标签，仅输出预测结果。")

with open(test_file, 'r', encoding='utf-8') as f:
    for line_num, line in enumerate(f, 1):
        if has_label:
            text, label = split_line(line, has_label=True)
            if text is None:
                continue
            if text:
                test_texts.append(text)
                test_labels.append(label if label else 'unknown')
        else:
            line = line.strip()
            if line:
                test_texts.append(line)
                test_labels = None  # 标记无标签

print(f"读取 {len(test_texts)} 条测试数据。")
if has_label and test_labels:
    valid_label_count = sum(1 for l in test_labels if l and l != 'unknown')
    print(f"其中包含标签的数据 {valid_label_count} 条。")

if len(test_texts) == 0:
    print("错误：没有读取到任何有效的测试数据！")
    exit(1)

# ------------------ 预测 ------------------
test_cut = [cut(t) for t in test_texts]
X_test = vectorizer.transform(test_cut)
predictions = model.predict(X_test)

# ------------------ 输出预测结果 ------------------
print("=" * 50)
print("预测结果")
print("=" * 50)
for i, (text, pred) in enumerate(zip(test_texts, predictions)):
    if has_label and test_labels and i < len(test_labels):
        true = test_labels[i]
        print(f"{i+1}. {text}\n   真实：{true}  预测：{pred}")
    else:
        print(f"{i+1}. {text}\n   预测：{pred}")
    print("-" * 40)

# ------------------ 若测试集有标签，输出评估报告 ------------------
if has_label and test_labels and any(l != 'unknown' for l in test_labels):
    # 过滤掉 'unknown' 的无效标签
    valid_indices = [i for i, l in enumerate(test_labels) if l != 'unknown']
    if valid_indices:
        valid_test_labels = [test_labels[i] for i in valid_indices]
        valid_predictions = [predictions[i] for i in valid_indices]
        
        print("\n" + "=" * 50)
        print("模型评估")
        print("=" * 50)
        print(f"准确率：{accuracy_score(valid_test_labels, valid_predictions):.2f}")
        print("\n混淆矩阵：")
        all_labels = sorted(set(valid_test_labels) | set(model.classes_))
        print(confusion_matrix(valid_test_labels, valid_predictions, labels=all_labels))
        print("\n详细报告：")
        print(classification_report(valid_test_labels, valid_predictions, zero_division=0))
    else:
        print("\n警告：没有有效的标签数据用于评估。")
else:
    print("\n注意：测试集没有标签，仅输出预测结果。")
