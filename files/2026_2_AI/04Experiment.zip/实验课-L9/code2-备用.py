# -*- coding: utf-8 -*-
"""
古诗词情绪分类器 - 交互式选择文件版

"""

import jieba
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix
import tkinter as tk
from tkinter import filedialog
import re

# ========== 交互式选择文件 ==========
root = tk.Tk()
root.withdraw()

print("请选择训练数据文件...")
train_file = filedialog.askopenfilename(
    title="选择训练数据文件",
    filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")]
)
if not train_file:
    print("未选择训练文件，程序退出。")
    exit()

print("请选择测试数据文件...")
test_file = filedialog.askopenfilename(
    title="选择测试数据文件",
    filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")]
)
if not test_file:
    print("未选择测试文件，程序退出。")
    exit()

# 测试文件是否包含标签（False=自动检测，True=强制有标签）
test_has_label = False
# ==========================================

def split_line(line, has_label=True):
    """智能分割每行数据，支持 Tab 和空格分隔符。返回 (text, label)"""
    line = line.strip()
    if not line:
        return None, None
    if not has_label:
        return line, ''
    
    # 优先 Tab
    if '\t' in line:
        parts = line.split('\t', 1)
        text = parts[0].strip()
        label = parts[1].strip() if len(parts) > 1 else ''
        return text, label
    
    # 尝试空格
    parts = re.split(r'\s+', line, maxsplit=1)
    if len(parts) == 2:
        text = parts[0].strip()
        label = parts[1].strip()
        # 若第二部分过长或含标点，视为文本一部分（无标签）
        if len(label) > 20 or any(ch in label for ch in ['，', '。', '？', '！', '；', '：']):
            return line, ''
        return text, label
    else:
        return line, ''

# ------------------ 训练数据读取 ------------------
print("正在读取训练数据...")
texts, labels = [], []
with open(train_file, 'r', encoding='utf-8') as f:
    for line_num, line in enumerate(f, 1):
        text, label = split_line(line, has_label=True)
        if text is None:
            continue
        if text and label:
            texts.append(text)
            labels.append(label)
        elif text and not label:
            print(f"警告：训练数据第 {line_num} 行没有标签，将使用 'unknown'")
            texts.append(text)
            labels.append('unknown')

if len(texts) == 0:
    print("错误：没有读取到任何有效的训练数据！")
    exit(1)
print(f"读取 {len(texts)} 条训练数据。")

# ------------------ 分词 ------------------
print("正在进行中文分词...")
def cut(text):
    return ' '.join(jieba.cut(text))

texts_cut = [cut(t) for t in texts]

# ------------------ 特征提取 ------------------
vectorizer = CountVectorizer(token_pattern=r"(?u)\b\w+\b")
X_train = vectorizer.fit_transform(texts_cut)
print(f"特征维度：{X_train.shape}")

if X_train.shape[1] == 0:
    print("错误：词汇表为空，请检查训练数据内容。")
    exit(1)

# ------------------ 训练模型 ------------------
model = MultinomialNB()
model.fit(X_train, labels)
print("模型训练完成。\n")

# ------------------ 测试数据读取（自动检测标签） ------------------
def detect_has_label(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        first = f.readline().strip()
        if not first:
            return False
        if '\t' in first:
            parts = first.split('\t', 1)
            if len(parts) == 2 and parts[1].strip():
                return True
        parts = re.split(r'\s+', first, maxsplit=1)
        if len(parts) == 2:
            second = parts[1].strip()
            if len(second) <= 20 and not any(ch in second for ch in ['，', '。', '？', '！']):
                return True
    return False

if test_has_label is True:
    has_label = True
    print("根据用户设置：测试集包含标签。")
else:
    has_label = detect_has_label(test_file)
    if has_label:
        print("自动检测：测试集包含标签，将进行评估。")
    else:
        print("自动检测：若测试集不包含标签，则仅输出预测结果。")

test_texts = []
test_labels = [] if has_label else None
with open(test_file, 'r', encoding='utf-8') as f:
    for line in f:
        if has_label:
            text, label = split_line(line, has_label=True)
            if text:
                test_texts.append(text)
                test_labels.append(label if label else 'unknown')
        else:
            line = line.strip()
            if line:
                test_texts.append(line)

print(f"读取 {len(test_texts)} 条测试数据。")
if len(test_texts) == 0:
    print("错误：没有测试数据！")
    exit(1)

# ------------------ 预测（关键修复：使用 X_test，而不是 test_cut） ------------------
test_cut = [cut(t) for t in test_texts]
X_test = vectorizer.transform(test_cut)      # 正确生成二维特征矩阵
predictions = model.predict(X_test)          # 修复：传入二维数组

# ------------------ 输出结果 ------------------
print("=" * 50)
print("预测结果")
print("=" * 50)
for i, (text, pred) in enumerate(zip(test_texts, predictions)):
    if has_label and test_labels and i < len(test_labels):
        print(f"{i+1}. {text}\n   真实：{test_labels[i]}  预测：{pred}")
    else:
        print(f"{i+1}. {text}\n   预测：{pred}")
    print("-" * 40)

# ------------------ 评估（如果有标签） ------------------
if has_label and test_labels and any(l != 'unknown' for l in test_labels):
    valid_idx = [i for i, l in enumerate(test_labels) if l != 'unknown']
    if valid_idx:
        true = [test_labels[i] for i in valid_idx]
        pred = [predictions[i] for i in valid_idx]
        print("\n" + "=" * 50)
        print("模型评估")
        print("=" * 50)
        print(f"准确率：{accuracy_score(true, pred):.2f}")
        print("\n混淆矩阵：")
        all_labels = sorted(set(true) | set(model.classes_))
        print(confusion_matrix(true, pred, labels=all_labels))
        print("\n详细报告：")
        print(classification_report(true, pred, zero_division=0))
    else:
        print("\n没有有效的标签数据用于评估。")
else:
    print("\n测试集无标签，仅输出预测结果。")
