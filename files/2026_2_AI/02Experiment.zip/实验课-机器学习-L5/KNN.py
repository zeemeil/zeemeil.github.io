import cv2
import numpy as np
import os
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# --------------------------------------------------------
# 1. 特征提取函数
# --------------------------------------------------------
def extract_color_features(image_path):
    """
    加载图像，计算并返回图像的平均BGR颜色值作为特征向量。
    对于新生而言，这是最简单且直观的特征。

    参数:
        image_path (str): 图像文件的路径。

    返回:
        numpy.array: 包含 (B均值, G均值, R均值) 的特征向量。
    """
    # 读取图像
    img = cv2.imread(image_path)

    # 检查图像是否成功加载
    if img is None:
        print(f"警告: 无法加载图像 {image_path}")
        return None

    # 计算每个颜色通道的平均值 (BGR顺序)
    # np.mean(img, axis=(0, 1)) 计算了所有像素在每个通道上的平均值
    (B_mean, G_mean, R_mean) = np.mean(img, axis=(0, 1))

    # 返回一个包含三个平均值的特征向量
    return np.array([B_mean, G_mean, R_mean])
# --------------------------------------------------------
# 2. 数据加载与特征提取
# --------------------------------------------------------

# 基础目录（请替换为实际路径）
base_dir = r'C:\Users\502\Desktop\experiment_data' 
data_paths = {
    "nut": os.path.join(base_dir, 'nuts'),        # 螺母目录
    "washer": os.path.join(base_dir, 'washers')   # 垫片目录
}

# 存储特征(X)和标签(Y)的列表
features = []
labels = []
label_map = {"nut": 0, "washer": 1} # 映射：螺母=0，垫片=1

print("--- 开始加载数据并提取特征 ---")

# 遍历每个类别文件夹
for item_name, folder_path in data_paths.items():
    label = label_map[item_name]
    print(f"处理类别: {item_name} (标签: {label})")

    # 遍历文件夹中的所有文件
    for filename in os.listdir(folder_path):
        if filename.endswith(('.jpg', '.jpeg', '.png')):
            image_path = os.path.join(folder_path, filename)
            
            # 提取特征
            feature_vector = extract_color_features(image_path)
            
            if feature_vector is not None:
                features.append(feature_vector)
                labels.append(label)

# 将列表转换为 NumPy 数组
X = np.array(features)
Y = np.array(labels)

print(f"总共提取了 {len(X)} 个样本的特征。")
print(f"特征矩阵 X 的形状: {X.shape}") 
print(f"标签向量 Y 的形状: {Y.shape}")
print("--- 数据加载完成 ---")
# --------------------------------------------------------
# 3. 模型训练与评估
# --------------------------------------------------------

print("\n--- 开始训练 K-NN 模型 ---")

# 3.1 数据分割
# 将数据随机分成 70% 训练集 和 30% 测试集
# X_train: 训练特征, X_test: 测试特征
# y_train: 训练标签, y_test: 测试标签
X_train, X_test, y_train, y_test = train_test_split(
    X, 
    Y, 
    test_size=0.3, # 30% 用于测试
    random_state=42, # 固定的随机种子，确保每次运行结果一致
    stratify=Y # 确保训练集和测试集的类别比例与原始数据一致
)

print(f"训练集大小: {len(X_train)}，测试集大小: {len(X_test)}")


# 3.2 模型实例化与训练
# 选择 K-近邻 (K-NN) 分类器，设定 k=5 (n_neighbors=5)
k = 5
model = KNeighborsClassifier(n_neighbors=k)

# 使用训练数据对模型进行拟合 (训练)
model.fit(X_train, y_train)

print(f"K-NN 模型 (k={k}) 训练完成。")


# 3.3 模型评估
# 在测试集上进行预测
y_pred = model.predict(X_test)

# 计算准确率 (准确率 = 正确预测的数量 / 总测试样本数量)
accuracy = accuracy_score(y_test, y_pred)

print(f"\n--- 模型评估结果 ---")
print(f"模型在测试集上的准确率: {accuracy * 100:.2f}%")


# 3.4 示例预测 (选做)
# 假设我们想预测测试集中的第一个样本
sample_feature = X_test[0].reshape(1, -1) # 转换成 (1, 3) 的形状
prediction = model.predict(sample_feature)
actual_label = y_test[0]

# 逆向映射，将标签 0/1 转换回名称
inverse_label_map = {v: k for k, v in label_map.items()}
predicted_item = inverse_label_map[prediction[0]]
actual_item = inverse_label_map[actual_label]

print("\n--- 单个样本预测示例 ---")
print(f"测试样本特征 (平均BGR): {sample_feature[0]}")
print(f"真实类别 (标签 {actual_label}): {actual_item}")
print(f"预测类别 (标签 {prediction[0]}): {predicted_item}")
