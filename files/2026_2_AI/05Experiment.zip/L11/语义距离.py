from gensim.models import KeyedVectors
import numpy as np

# 1. 加载预训练模型
pretrained_path = r'C:\Users\502\Desktop\sgns.sikuquanshu.bigram'
print("正在加载四库全书预训练模型...")
# 注意：如果文件较大，加载可能需要几十秒
vectors = KeyedVectors.load_word2vec_format(pretrained_path, binary=False)

def get_vector_safe(word):
    """安全获取向量：词不行就试字"""
    if word in vectors:
        return vectors[word]
    # 如果是两个字，尝试取平均向量（简单的语义合成）
    if len(word) > 1:
        v = []
        for char in word:
            if char in vectors:
                v.append(vectors[char])
        if v:
            return np.mean(v, axis=0)
    return None

def show_distance_v2(w1, w2):
    v1 = get_vector_safe(w1)
    v2 = get_vector_safe(w2)
    
    if v1 is not None and v2 is not None:
        # 手动计算余弦相似度
        sim = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
        print(f"【{w1}】与【{w2}】的语义关联度为: {sim:.4f}")
    else:
        print(f"无法获取【{w1}】或【{w2}】的向量，请换个词试试（如：月、归、家）")

# 2. 课堂演示
print("\n" + "="*30)
print("演示一：古诗词意象的内在联系")
show_distance_v2("月", "乡")    # 单字通常在古文中更通用
show_distance_v2("明月", "故乡")
show_distance_v2("梅", "雪")    # 经典的咏物意象
