# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import re
import numpy as np
from gensim.models import KeyedVectors
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score

# ========== 实验配置 ==========
train_file = r'C:\Users\502\Desktop\train.txt'
test_file = r"C:\Users\502\Desktop\test.txt"
pretrained_path = r'C:\Users\502\Desktop\sgns.sikuquanshu.bigram'

MAX_LEN = 40        # 增加长度，包含更多字
EMBED_DIM = 300     
HIDDEN_DIM = 64     # 进一步压缩隐藏层，防止过拟合
BATCH_SIZE = 8      # 减小 Batch，增加梯度更新频率
EPOCHS = 100        # 增加训练次数，让模型有时间从 1.6 的 Loss 走出来
LEARNING_RATE = 0.005 # 提高学习率，强行推动模型学习
# ==============================

def clean_path(path):
    return re.sub(r'[\x00-\x1f\x7f\u200e\u200f\u202a-\u202e]', '', path)

def split_line(line, has_label=True):
    line = line.strip()
    if not line: return None, None
    if '\t' in line:
        parts = line.split('\t', 1)
        return parts[0].strip(), (parts[1].strip() if len(parts) > 1 else 'unknown')
    parts = re.split(r'\s+', line, maxsplit=1)
    if len(parts) == 2: return parts[0].strip(), parts[1].strip()
    return line, ''

# 1. 数据读取：【修改点：按字读取】
train_texts, train_labels = [], []
with open(clean_path(train_file), 'r', encoding='utf-8') as f:
    for line in f:
        t, l = split_line(line)
        if t:
            train_texts.append(t)
            train_labels.append(l)

# 构建字表
chars = set()
for text in train_texts:
    for char in text: chars.add(char)
char2idx = {char: i + 2 for i, char in enumerate(chars)}
char2idx["<PAD>"], char2idx["<UNK>"] = 0, 1

# 加载预训练权重
print("正在加载预训练模型...")
vectors = KeyedVectors.load_word2vec_format(pretrained_path, binary=False)
weights_matrix = np.zeros((len(char2idx), EMBED_DIM))
found = 0
for char, i in char2idx.items():
    if char in vectors:
        weights_matrix[i] = vectors[char]
        found += 1
    else:
        weights_matrix[i] = np.random.normal(scale=0.6, size=(EMBED_DIM, ))
print(f"字表先验语义覆盖率：{found}/{len(char2idx)}")

label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(train_labels)
num_classes = len(label_encoder.classes_)

# 2. 模型：使用 GRU 代替 RNN，并增加最后全连接层的强度
class SimpleGRU(nn.Module):
    def __init__(self, weights_matrix, hidden_dim, output_dim):
        super().__init__()
        self.embedding = nn.Embedding.from_pretrained(
            torch.FloatTensor(weights_matrix), 
            freeze=True, # 依然冻结
            padding_idx=0
        )
        # GRU 在小样本下比 RNN 更容易训练
        self.gru = nn.GRU(EMBED_DIM, hidden_dim, batch_first=True, bidirectional=True)
        self.fc = nn.Linear(hidden_dim * 2, output_dim) # 双向 GRU 维度翻倍

    def forward(self, x):
        embeds = self.embedding(x)
        _, hidden = self.gru(embeds) # hidden shape: [num_layers*num_directions, batch, hidden_dim]
        # 拼接双向的最后状态
        out = torch.cat((hidden[-2,:,:], hidden[-1,:,:]), dim=1)
        return self.fc(out)

# 3. 数据加载与训练
class CharDataset(Dataset):
    def __init__(self, texts, labels, char2idx):
        self.texts = texts
        self.labels = labels
        self.char2idx = char2idx
    def __len__(self): return len(self.texts)
    def __getitem__(self, idx):
        indices = [self.char2idx.get(c, 1) for c in self.texts[idx]][:MAX_LEN]
        indices += [0] * (MAX_LEN - len(indices))
        return torch.tensor(indices), torch.tensor(self.labels[idx])

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = SimpleGRU(weights_matrix, HIDDEN_DIM, num_classes).to(device)
train_loader = DataLoader(CharDataset(train_texts, y_train, char2idx), batch_size=BATCH_SIZE, shuffle=True)
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
criterion = nn.CrossEntropyLoss()

print("开始训练...")
model.train()
for epoch in range(EPOCHS):
    l_sum = 0
    for x, y in train_loader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        loss = criterion(model(x), y)
        loss.backward()
        optimizer.step()
        l_sum += loss.item()
    if (epoch + 1) % 20 == 0:
        print(f"Epoch {epoch+1}, Loss: {l_sum/len(train_loader):.4f}")

# 4. 评估
test_texts, test_labels_true = [], []
with open(clean_path(test_file), 'r', encoding='utf-8') as f:
    for line in f:
        t, l = split_line(line)
        if t:
            test_texts.append(t)
            test_labels_true.append(l)

model.eval()
preds = []
with torch.no_grad():
    for text in test_texts:
        indices = [char2idx.get(c, 1) for c in text][:MAX_LEN]
        indices += [0] * (MAX_LEN - len(indices))
        out = model(torch.tensor([indices]).to(device))
        preds.append(label_encoder.inverse_transform([torch.argmax(out, 1).item()])[0])

print(f"\n准确率: {accuracy_score(test_labels_true, preds):.2f}")
print(classification_report(test_labels_true, preds, zero_division=0))
