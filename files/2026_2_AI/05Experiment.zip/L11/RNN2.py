# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import jieba
import re
import numpy as np
from gensim.models import KeyedVectors
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, accuracy_score

# ========== 实验配置 ==========
train_file = r'C:\Users\502\Desktop\train.txt'
test_file = r"C:\Users\502\Desktop\test.txt"
# 您下载解压后的四库全书词向量路径
pretrained_path = r'C:\Users\502\Desktop\sgns.sikuquanshu.bigram'

MAX_LEN = 30        # 序列最大长度
EMBED_DIM = 300     # 四库全书预训练向量固定为 300 维
HIDDEN_DIM = 128    # 降低隐藏层维度减少过拟合
BATCH_SIZE = 16
EPOCHS = 20
LEARNING_RATE = 0.001
# ==============================

def clean_path(path):
    return re.sub(r'[\x00-\x1f\x7f\u200e\u200f\u202a-\u202e]', '', path)

def split_line(line, has_label=True):
    line = line.strip()
    if not line: return None, None
    if not has_label: return line, ''
    if '\t' in line:
        parts = line.split('\t', 1)
        return parts[0].strip(), (parts[1].strip() if len(parts) > 1 else 'unknown')
    parts = re.split(r'\s+', line, maxsplit=1)
    if len(parts) == 2:
        text, label = parts[0].strip(), parts[1].strip()
        if len(label) > 20 or any(ch in label for ch in ['，', '。', '？', '！']):
            return line, ''
        return text, label
    return line, ''

# 1. 数据读取
train_file, test_file = clean_path(train_file), clean_path(test_file)
train_texts, train_labels = [], []
with open(train_file, 'r', encoding='utf-8') as f:
    for line in f:
        t, l = split_line(line, has_label=True)
        if t:
            train_texts.append(t)
            train_labels.append(l if l else 'unknown')

# 2. 构建词汇表与加载预训练权重
print("正在构建词汇表...")
all_tokens = [list(jieba.cut(t)) for t in train_texts]
word_set = set(word for tokens in all_tokens for word in tokens)
word2idx = {word: i + 2 for i, word in enumerate(word_set)}
word2idx["<PAD>"], word2idx["<UNK>"] = 0, 1

print(f"正在加载预训练模型: {pretrained_path}...")
# 加载四库全书词向量
vectors = KeyedVectors.load_word2vec_format(pretrained_path, binary=False)

# 创建权重矩阵
weights_matrix = np.zeros((len(word2idx), EMBED_DIM))
found_count = 0
for word, i in word2idx.items():
    if word in vectors:
        weights_matrix[i] = vectors[word]
        found_count += 1
    else:
        # 没找到的词使用随机正态分布初始化
        weights_matrix[i] = np.random.normal(scale=0.6, size=(EMBED_DIM, ))
print(f"预训练导入完成：{found_count}/{len(word2idx)} 个词获得了先验语义")

label_encoder = LabelEncoder()
train_labels_idx = label_encoder.fit_transform(train_labels)
num_classes = len(label_encoder.classes_)

# 3. 定义数据集与模型
class PoetryDataset(Dataset):
    def __init__(self, texts, labels_idx, word2idx, max_len):
        self.texts = texts
        self.labels = labels_idx
        self.word2idx = word2idx
        self.max_len = max_len

    def __len__(self): return len(self.texts)

    def __getitem__(self, idx):
        tokens = list(jieba.cut(self.texts[idx]))
        indices = [self.word2idx.get(t, 1) for t in tokens][:self.max_len]
        indices += [0] * (self.max_len - len(indices))
        return torch.tensor(indices), torch.tensor(self.labels[idx])

class RNNPretrainedModel(nn.Module):
    def __init__(self, weights_matrix, hidden_dim, output_dim):
        super().__init__()
        # 加载预训练权重
        self.embedding = nn.Embedding.from_pretrained(
            torch.FloatTensor(weights_matrix), 
            freeze=True, # 微调
            padding_idx=0
        )
        self.rnn = nn.RNN(EMBED_DIM, hidden_dim, batch_first=True)
        self.dropout = nn.Dropout(0.5)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        embeds = self.embedding(x)
        _, hidden = self.rnn(embeds)
        # 取最后一个隐藏状态并应用 Dropout
        out = self.dropout(hidden.squeeze(0))
        return self.fc(out)

# 4. 训练模型
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = RNNPretrainedModel(weights_matrix, HIDDEN_DIM, num_classes).to(device)
train_loader = DataLoader(PoetryDataset(train_texts, train_labels_idx, word2idx, MAX_LEN), 
                          batch_size=BATCH_SIZE, shuffle=True)
optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
criterion = nn.CrossEntropyLoss()

print(f"开始 RNN 训练 (设备: {device})...")
model.train()
for epoch in range(EPOCHS):
    total_loss = 0
    for texts_batch, labels_batch in train_loader:
        texts_batch, labels_batch = texts_batch.to(device), labels_batch.to(device)
        optimizer.zero_grad()
        loss = criterion(model(texts_batch), labels_batch)
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    if (epoch + 1) % 5 == 0:
        print(f"Epoch {epoch+1}/{EPOCHS}, Loss: {total_loss/len(train_loader):.4f}")

# 5. 评估
print("\n正在预测测试集...")
test_texts, test_labels_true = [], []
with open(test_file, 'r', encoding='utf-8') as f:
    for line in f:
        t, l = split_line(line, has_label=True)
        if t:
            test_texts.append(t)
            test_labels_true.append(l if l else 'unknown')

model.eval()
all_preds = []
with torch.no_grad():
    for raw_text in test_texts:
        tokens = list(jieba.cut(raw_text))
        indices = [word2idx.get(t, 1) for t in tokens][:MAX_LEN]
        indices += [0] * (MAX_LEN - len(indices))
        input_tensor = torch.tensor([indices]).to(device)
        output = model(input_tensor)
        pred_idx = torch.argmax(output, dim=1).item()
        all_preds.append(label_encoder.inverse_transform([pred_idx])[0])

# 输出指标报告
valid_indices = [i for i, l in enumerate(test_labels_true) if l != 'unknown' and l != '']
if valid_indices:
    y_true = [test_labels_true[i] for i in valid_indices]
    y_pred = [all_preds[i] for i in valid_indices]
    print("\n" + "=" * 50)
    print(f"模型评估 (RNN + 四库全书预训练)")
    print(f"准确率 (Accuracy): {accuracy_score(y_true, y_pred):.2f}")
    print("=" * 50)
    print(classification_report(y_true, y_pred, zero_division=0))
