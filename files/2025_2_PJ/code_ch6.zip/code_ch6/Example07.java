package com.itheima;

public class Example07 {
    public static void main(String[] args) {
        String s = "itcast";
        System.out.println(s.charAt(8));
    }
}
