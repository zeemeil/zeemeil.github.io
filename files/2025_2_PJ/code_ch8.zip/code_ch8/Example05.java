package com.itheima;

public class Example05{
      public static void main(String[] args) {
          Inter<String> inter = new InterImpl();
          inter.show("hello");
      }
}