package com.itheima;

public interface Inter<T> {
        public abstract void show(T t);
}