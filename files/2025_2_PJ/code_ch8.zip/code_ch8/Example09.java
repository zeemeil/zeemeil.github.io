package com.itheima;/*
package com.itheima;

import java.util.ArrayList;
import java.util.Collection;

public class Example09 {
    // 设定类型通配符的上限，此时传入的类型实参必须是Number类型或者Number类型的子类
    public static void getElement(Collection<? extends Number> coll){}
    public static void main(String[] args) {
        // 创建Collection对象，传入Number类型的类型实参
        Collection<Number> list1 = new ArrayList<Number>();
        // 创建Collection对象，传入Integer类型的类型实参
        Collection<Integer> list2 = new ArrayList<Integer>();
        // 创建Collection对象，传入String类型的类型实参
        Collection<String> list3 = new ArrayList<String>();
        getElement(list1);
        getElement(list2);
        getElement(list3);
    }
}*/
